<?php
require './database.php';
session_start();


if(isset($_POST['signupBtn'])){
    $error = array();
    $email = ($_POST['email']);
    $password = ($_POST['pass']);
    $firstName = ($_POST['fName']);
    $lastName = ($_POST['lName']);
    $phoneNumber = ($_POST['phonenumb']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $emailErr = "Invalid email format";
    }else{
    $user_check_query = "SELECT * FROM usertable WHERE email = '$email' LIMIT 1";
    $check_result = mysqli_query($connection, $user_check_query);
    $emailvalidity = mysqli_fetch_assoc($check_result);
    if($emailvalidity['email'] === $email){
        echo "Email already exists!";
    }else{
        if(empty($email) || empty($password) || empty($firstName) || empty($lastName) || empty($phoneNumber)){
            echo "Please fill out all the fields!";
        }else{
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $user_acc_query = "INSERT INTO usertable (email, password, firstName, lastName, phoneNumber) VALUES ('{$_POST['email']}', '$encpass', '{$_POST['fName']}', '{$_POST['lName']}', '{$_POST['phonenumb']}')";
            $sqlCreate = mysqli_query($connection, $user_acc_query);
            echo "<script>alert('Registered successfully')</script>";
            header("Location: ./login.php");
        }
    }
}
}

if(isset($_POST['loginBtn'])){
    $email = ($_POST['email']);
    $password = ($_POST['pass']);
    $check_email = "SELECT * FROM usertable WHERE email = '$email'";
    $res = mysqli_query($connection, $check_email);
    if(mysqli_num_rows($res) > 0){
        $fetch = mysqli_fetch_assoc($res);
        $fetch_pass = $fetch['password'];
        if(password_verify($password, $fetch_pass)){
            $_SESSION['status'] = 'valid';
              $_SESSION['email'] = $email;
              $_SESSION['password'] = $password;
                header('location: home.php');
            }else{
                echo "<script>alert('error')";
                header('location: ./login.php');
            }
        }else{
            $errors['email'] = "Incorrect email or password!";
        }
    }else{
        $errors['email'] = "It's look like you're not yet a member! Click on the bottom link to signup.";
    }
    

   
     
?>