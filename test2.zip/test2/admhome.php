<?php
require './adminFunctions.php';
echo 'testing!';

?>