<?php
require './userLogin-Signup.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/signup.css">
    <title>SIGNUP</title>
</head>

<body>

    <div class="container">
        <div id="imge">
            <img src="image/bgc.png">
        </div>
        <div class="bud">
            <div class="die">
                <form action="#" method="post">
                    <h1>Create Account</h1>
                    <input name="email" type="email" placeholder="Email" />
                    <input name="pass" type="password" placeholder="Password" autocomplete="off"/>
                    <input name="fName" type="text" placeholder="First Name" />
                    <input name="lName" type="text" placeholder="Last Name" />
                    <input name="phonenumb" type="text" placeholder="Phone Number" />
                    <input type="submit" value="Sign up" name="signupBtn">
                    <input type="button" value="Login" name="loginBtn">
                </form>

            </div>
        </div>
    </div>
</body>

</html>