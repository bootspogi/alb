<?php
require './userLogin-Signup.php';
if($_SESSION['status'] == 'invalid' || empty($_SESSION['status'])){
    $_SESSION['status'] = 'invalid';
    echo "<script>window.location.href ='./login.php'</script>";
}

if($_SESSION['status'] == 'valid' && $_SESSION['email'] == true){
    echo "<script>window.location.href ='./home.php'</script>";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./css/login.css" />
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet" type='text/css'>
    <title>ALB</title>
</head>

<body>
    <div class="container">
        <div class="image">
            <img src="image/bg.svg">
        </div>

        <div class="cons">
            <div class="tainer">

                <form action="./login.php" method="post">
                    <h1>SIGN IN</h1>
                    <div class="usr">
                        <i class="fa fa-user icon"></i>
                        <input name="email" type="email" placeholder="Email" />
                    </div>

                    <div class="usr">
                        <i class="fa fa-lock icon"></i>
                        <input name="pass" type="password" placeholder="Password" />
                    </div>
                    <a href="#">Forgot your password?</a>
                    <input type="submit" name="loginBtn" class="ac" value="SIGN IN"></input>
                </form>
                <pre>Doesn't have an account?</pre>
                <button class="btn-lg btn-success" onclick="gotoSignup()">SIGN UP</button>
                <script>
                    function gotoSignup() {
                        if (confirm("Do you want to Sign up for a new account?")) {
                            window.location.replace("./signup.php");
                        }
                    }
                </script>
            </div>
        </div>
    </div>
</body>

</html>