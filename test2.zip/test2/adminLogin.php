<?php
require './adminFunctions.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./css/login.css" />
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet" type='text/css'>
    <title>ALB</title>
</head>

<body>
    <div class="container">
        <div class="image">
            <img src="image/bg.svg">
        </div>

        <div class="cons">
            <div class="tainer">

                <form action="./adminLogin.php" method="post">
                    <h1>SIGN IN</h1>
                    <div class="usr">
                        <i class="fa fa-user icon"></i>
                        <input name="user" type="username" placeholder="Username" />
                    </div>

                    <div class="usr">
                        <i class="fa fa-lock icon"></i>
                        <input name="pass" type="password" placeholder="Password" />
                    </div>
                    <input type="submit" name="admloginBtn" class="ac" value="LOGIN"></input>
                </form>
            </div>
        </div>
    </div>
</body>

</html>