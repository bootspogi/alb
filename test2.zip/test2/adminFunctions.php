<?php
require './database.php';
session_start();
 if(isset($_POST['admloginBtn'])){
    $adm_user = ($_POST['user']);
    $adm_pass = ($_POST['pass']);
    $check_user = "SELECT * FROM admintable WHERE user = '$adm_user'";
    $res = mysqli_query($connection, $check_user);
    if(mysqli_num_rows($res) > 0){
        $fetch = mysqli_fetch_assoc($res);
        $fetch_pass = $fetch['password'];
        if(password_verify($password, $fetch_pass)){
              $_SESSION['user'] = $adm_user;
              $_SESSION['password'] = $adm_pass;
                header('location: ./admhome.php');
            }else{
                echo "<script>alert('error')";
                header('location: ./adminLogin.php');
            }
        }
    }
?>