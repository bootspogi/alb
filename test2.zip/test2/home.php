<?php
require "./database.php";
session_start();

if($_SESSION['status'] == 'invalid' || empty($_SESSION['status'])){
    header('./login.php');
}
$email = $_SESSION['email'];

if(isset($_POST['regBanks'])){
    $error = array();
    $bank = ($_POST['Bank']);
    $accountnumber = ($_POST['AccountNumber']);
    $address = ($_POST['Address']);
    $maiden = ($_POST['Maiden']);
    $addbankquery = "SELECT * FROM $bank WHERE accountnumber = $accountnumber maiden = $maiden and address = $address";
    $check = mysqli_query($connection, $addbankquery);
    if($check->num_rows>0){
    $accountvalidity = mysqli_fetch_assoc($check_result);
    if($accountvalidity){
        $insertbank = "UPDATE usertable SET bankaccount = $accountnumber WHERE email = $email";
        $checkinsert = mysqli_query($connection, $insertbank);
        $insertresult = mysqli_fetch_all($checkinsert);
        if($insertresult == true){
            echo "Registration successful!";
        }
        else{
            echo "error";
        }
    }
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/home.css">
    <title>ALB</title>
</head>

<body>
    <nav>
        <div class="logo">
            <h4>All Your Bank</h4>
        </div>
        <ul class="nav-links">
            <li> <a href="#">Account</a></li>
            <li> <a href="#">Support</a></li>
            <li> <a href="./logout.php">Logout</a></li>
        </ul>
        <div class="burger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
    </nav>
    <h3>Register your bank account here!</h3>
    <button class="openReg" >Enroll your bank account</button>
    <div class="bg-modal">
	<div class="modal-contents">

		<div class="close">+</div>
        <form class="regbanks" method="post">
        <h3>Register your bank account here!</h3>
            <input type="text" placeholder="Enter Bank" name="Bank" required>
            <input type="text" placeholder="Enter Account Number" name="AccountNumber" required>
            <input type="text" placeholder="Enter Billing Addres" name="Address" required>
            <label for="maiden">Enter your mother's maiden name. (This is for verification only and will be encrypted in our database.)</label>
            <input type="text" placeholder="Mother's Maiden Name" name="Maiden" required>
            <button type="submit" class="btn" name="regBank">Add Bank</button>
            <button type="button" class="btncancel" onclick="closeForm()">Close</button>
        </form>

	</div>
</div>

    <button class="openBanks" onclick="openBank();">Your enrolled bank accounts</button>
    <div class="homecon" id="showBankdiv">
    <form action="./home.php" class="showbanks" method="post">
    
    </form>
    </div>
        <script>
document.getElementById('.openReg').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "flex";
});

document.querySelector('.close').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "none";
});
</script>
</body>
</html>