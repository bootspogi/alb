<?php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'all-your-bank';

$connection = mysqli_connect($host, $user, $password, $database);

?>